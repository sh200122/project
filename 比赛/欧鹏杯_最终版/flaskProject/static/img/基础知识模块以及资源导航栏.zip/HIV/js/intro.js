$(document).ready(function(){

    $(".img").siblings().css('z-index','10');

    $("#intro").mouseenter(() => {
        $("#_line").animate({width:'60%'});
    });
  });
